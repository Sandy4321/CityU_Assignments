
public class ExEmployee extends Exception {
	
	private static final long serialVersionUID = 1L;

	public ExEmployee () { super( "Employee Error." ); }

	public ExEmployee ( String eMsg ) { super( eMsg ); }  

}

