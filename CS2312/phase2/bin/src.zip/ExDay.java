// TODO: Rememver to remove
public class ExDay extends Exception {

	private static final long serialVersionUID = 1L;

	public ExDay () {
		super("Day Error!");
	}
	public ExDay(String eMsg) {
		super(eMsg);
	}
}
