
public class ExEmployeeDuplicate extends ExEmployee {

	
	private static final long serialVersionUID = 1L;

	public ExEmployeeDuplicate () { super ("Employee already exists!"); } 
}
