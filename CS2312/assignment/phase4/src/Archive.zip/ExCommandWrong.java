
public class ExCommandWrong extends ExCommand {
	
	private static final long serialVersionUID = 1L;
	
	public ExCommandWrong () { super( "Wrong Command" ); }
	
	public ExCommandWrong (String message) { super( message ); }
}
