
public class ExTeamNotFound extends ExTeam {

	
	private static final long serialVersionUID = 1L;

	public ExTeamNotFound() {
		super ("Team not found!");
	}
	
	public ExTeamNotFound (String eMsg) {
		super (eMsg);
	}
	
}
