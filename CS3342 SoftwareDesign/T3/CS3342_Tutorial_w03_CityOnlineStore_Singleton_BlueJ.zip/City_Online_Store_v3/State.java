public interface State
{
    public int discount ();
    
    public  int deposit ();
    
    public  String type();
    
}
