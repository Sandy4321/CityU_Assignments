public class Typical implements State
{
    public int discount() { return 100; }

    public int deposit() { return 100; }
    
    public String type() {  return "Typical"; }
}
