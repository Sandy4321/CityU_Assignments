public class Golden implements State
{
    public int discount() { return 50; }

    public int deposit() { return 0; }
    
    public String type() {  return "Golden"; }
}
