public interface State
{

    public abstract int discount ();
    
    public abstract int deposit ();
    
    public abstract String type();
    
}
